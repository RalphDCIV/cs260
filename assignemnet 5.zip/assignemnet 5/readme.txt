o(n) add function
o(n) rmeove function
o(n^2) sort function



new code is from lines (41-101)