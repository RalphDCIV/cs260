#include <iostream>
#include <string>


struct node {
    int data; //data for the node
    node* next; //the data for the next node in the chain
    int order; //order in the list

};


node* createnode(int value) { // BIG O: O(1)
    node* newnode = new node; //declares a new node
    newnode->data = value; // sets the value of the node to the given value
    newnode->next = nullptr; //sets the node to have a next value of null 
    newnode->order = -1; //sets placeholder number in the order
    return newnode; //returns the node


}

void order(node*& head){  // BIG O: O(n)
    node* currentnode = head; //sets the current node as the head
    int num = 1;                //sets the num to 1
    while (currentnode) {       //runs through and adds one to each node
        currentnode->order = num; 
        num++;
        currentnode=currentnode->next;



    }






}


void print(node*& head){  // BIG O: O(n)
    if (head == nullptr){ //if there is nothing in the list...
    std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
    std::cout << "-------------------------------------------------------------" << std::endl; 
    std::cout << "No Data stored " << std::endl; //...tell the user and...
    return;  //...return -1.
    } else {
        node* currentnode = head; //sets the current node as the head
        std::cout << "-------------------------------------------------------------" << std::endl;
        while (currentnode) {       //runs through and prints each nodes order and data
            std::cout << "-------------------------------------------------------------" << std::endl;
            std::cout << "Node: " << currentnode->order << ", data: " << currentnode->data << std::endl;
            currentnode=currentnode->next;


        }
    }


}

void mid_enque(node*& head, int value, int place) {
        node* newnode = createnode(value); //creates the new node so it can then be added to the linked list

    if (head == nullptr) {  // if there is no head...

        head = newnode; //..make this node the head.
    } else if (place ==1) { //if the place is 1 
        node* current = head; // make the head a diffrent vairiable
        head = newnode; //set the new node to be the head
        head->next = current; // and point the new node at the old head
    } else {
        node* current = head; // make the head a diffrent vairiable
        while (current->next != nullptr) { //while the next node is not nothing...
            if (current->next->order == place) //if the next node has an order value equal to the one inputed...
            {
                node* before = current; //set current to a before vairable
                node* after = current->next; //set the one vairable that currently in th spot we want to after
                
                before->next = newnode; //point the before node to the new node
                newnode->next = after;  //and the new node to the after node
                return; 




            }
            
            current = current->next;        //...move to the next node
        }
            current->next = newnode; //set the pointer of the current node (the last one in the list) to be the newly created Node. (effectivly adding it to the end of the list)
    }







}

int mid_deque(node*& head, int place) {

    if (head == nullptr){ //if there is nothing in the list...
        std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "No Data stored " << std::endl; //...tell the user and...
        return -1;
    } else if (place == 1) {
            int newdata = head->data; //grab the data from the headnode...
        node* current = head; // set the head to be a seprate varaiable
        head = current->next; //set the next node to be the head
        delete current; //delete the head
        std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
        std::cout << "-------------------------------------------------------------" << std::endl; 
        return newdata; //... and return it.
    } else {
        node* current = head; // make the head a diffrent vairiable
        while (current->next != nullptr) { //while the next node is not nothing...
            if (current->next->order == place) {//if the next node has an order value equal to the one inputed...
            
                if (current->next->next == nullptr) { //check if the chosen vairiable is the last vairiable
                    node* before = current; //set current to a before vairable
                    node* justright = current->next; 

                    int value = justright->data;

                    before->next = nullptr;
                    delete justright;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    return value; 
                } else {
                    node* before = current; //set current to a before vairable
                    node* justright = current->next; 
                    node* after = current->next->next; //set after node 
                    
                    int value = justright->data;

                    before->next = after;
                    delete justright;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    return value; 
                    }



            }

            current = current->next;        //...move to the next node

        }
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "No Data stored " << std::endl;
        return -1;
    }
}

int mid_peek(node*& head, int place) {
    if (head == nullptr){ //if there is nothing in the list...
        std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "No Data stored " << std::endl; //...tell the user and...
        return -1;
    } else {
        node* current = head; // make the head a diffrent vairiable
        while (current->order != place) {
            if (current->next == nullptr){
                std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "Data not found " << std::endl;
                return -1;
            }
            current = current->next;        //...move to the next node
        }   
        int value = current->data;
        std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
        std::cout << "-------------------------------------------------------------" << std::endl; 
        return value;
    }
    
}



void enque(node*& head, int value) { // BIG O: O(n)
    node* newnode = createnode(value); //creates the new node so it can then be added to the linked list

    if (head == nullptr) {  // if there is no head...

        head = newnode; //..make this node the head.

    } else {
        node* current = head; // variable current is set to start at the head.

        while (current->next != nullptr) { //while the next node is not nothing...
            current = current->next;        //...move to the next node
        }
            current->next = newnode; //set the pointer of the current node (the last one in the list) to be the newly created Node. (effectivly adding it to the end of the list)
    }


}





int deque(node*& head) { // BIG O: O(1)

 if (head == nullptr){ //if there is nothing in the list...
    std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
    std::cout << "-------------------------------------------------------------" << std::endl; 
    std::cout << "No Data stored " << std::endl; //...tell the user and...
    return -1;  //...return -1.
 } else {
    int newdata = head->data; //grab the data from the headnode...
    node* current = head; // set the head to be a sepret vairaiable
    head = current->next; //set the next node to be the head
    delete current; //delete the head
    std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
    std::cout << "-------------------------------------------------------------" << std::endl; 
    return newdata; //... and return it.
 }
}

int peek(node*& head) { // BIG O: O(1)

 if (head == nullptr){ //if there is nothing in the list...
    std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
    std::cout << "-------------------------------------------------------------" << std::endl; 
    std::cout << "No Data stored " << std::endl; //...tell the user and...
    return -1;  //...return -1.
 } else {
    int newdata = head->data; //grab the data from the headnode...
    std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
    std::cout << "-------------------------------------------------------------" << std::endl; 
    return newdata; //... and return it.
 }
}








int main() {
    node* head = nullptr; //set the head to be nothing for we have nothing.
    std::string grosschoice;
    std::string grosschoice2;
    grosschoice = "null";
    int netchoice = 0;
    std::string grossnode;
    grossnode = "null";
    int devalue=0;
    int pevalue=0;
    int netnode = 0;
    int netnode2 = 0;
    bool on = true;
    while (on == true) {
        order(head);
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "press 1 to add a value to the end linked list" << std::endl;                  //Menu
        std::cout << "press 2 to get the value of the head node and then remove it" << std::endl;   //Menu
        std::cout << "press 3 to get the value of the head node without removing it" << std::endl;  //Menu
        std::cout << "press 4 to print out a list of all nodes" << std::endl;  //Menu
        std::cout << "press 5 to add a value at any location." << std::endl;  //Menu
        std::cout << "press 6 to get value and delete a value at any location." << std::endl;  //Menu
        std::cout << "press 7 to get value at any location." << std::endl;  //Menu
        
        
        
        std::cout << "press 8 to exit" << std::endl;                                                //Menu
                std::cout << "what would you like to do: ";                                      //Menu
        std::getline(std::cin, grosschoice);     //Get user input as str
        try {
            netchoice = std::stoi(grosschoice);        //change to int
        } catch (const std::invalid_argument& e) { //make sure it works
            netchoice = -1;
        } catch (const std::out_of_range& e) { // make sure it works again
            netchoice = -1;
        }



        if (netchoice == 1){ // choice for 1-----------------------------------------------------------------
            std::cout << "Input a valid intiger Value for the Node: ";    
            std::getline(std::cin, grosschoice);    //Get user input for value in Node
        try {
            netnode = std::stoi(grosschoice);
        } catch (const std::invalid_argument& e) {
            netnode = -1;
        } catch (const std::out_of_range& e) {
            netnode = -1;
        }
        enque(head, netnode); //call enque and let it do its thing

        } else if (netchoice == 2) { //choice for 2------------------------------------------------------------
            devalue = deque(head); //run deque
            std::cout << "Value: "<< devalue <<std::endl; //print the value

        } else if (netchoice == 3) { //choice for 3-------------------------------------------------------------
            pevalue = peek(head); //run peek

            std::cout << "Value: "<< pevalue <<std::endl; //print the value
        } else if (netchoice == 4) { //cholice for 4------------------------------------------------------
            print(head);

        } else if (netchoice == 5) { //cholice for 5----------------------------------------------------
            std::cout << "Input a valid intiger Value for the Node: " << std::endl;;    
            std::getline(std::cin, grosschoice);    //Get user input for value in Node
        try {
            netnode = std::stoi(grosschoice);
        } catch (const std::invalid_argument& e) {
            netnode = -1;
        } catch (const std::out_of_range& e) {
            netnode = -1;
        }

        std::cout << "Select what place you want to add the node to: " << std::endl;;    
            std::getline(std::cin, grosschoice2);    //Get user input for value in Node
        try {
            netnode2 = std::stoi(grosschoice2);
        } catch (const std::invalid_argument& e) {
            netnode2 = -1;
        } catch (const std::out_of_range& e) {
            netnode2 = -1;
        }

        mid_enque(head, netnode, netnode2);

        } else if (netchoice == 6) { //choice for 6----------------------------------------------------
            std::cout << "Select what place you want to add the node to: ";    
            std::getline(std::cin, grosschoice);    //Get user input for value in Node
        try {
            netnode = std::stoi(grosschoice);
        } catch (const std::invalid_argument& e) {
            netnode = -1;
        } catch (const std::out_of_range& e) {
            netnode = -1;
        }
        devalue = mid_deque(head, netnode); //call deenque and let it do its thing
        std::cout << "Value: "<< devalue <<std::endl; //print the value


        } else if (netchoice == 7) { //choice for 7----------------------------------------------------
            std::cout << "Select what place you want to add the node to: ";    
            std::getline(std::cin, grosschoice);    //Get user input for value in Node
        try {
            netnode = std::stoi(grosschoice);
        } catch (const std::invalid_argument& e) {
            netnode = -1;
        } catch (const std::out_of_range& e) {
            netnode = -1;
        }
        devalue = mid_peek(head, netnode); //call deenque and let it do its thing
        std::cout << "Value: "<< devalue <<std::endl; //print the value


        } else if (netchoice == 8) { //choice for 8-------------------------------------
            return 0; //exit program
        } else { //incorrect value
            std::cout << "Sorry didnt get that, please input a valid action... Or else." << std::endl; //yell at them and make an else pun.
        }

    }






}