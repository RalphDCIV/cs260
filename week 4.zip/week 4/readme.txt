---------------------------------------------------------------------------------------------------------------------------
________________Add a function to the middle of a linked list________________ lines 64 - 102

---------------------------------------------------------------------------------------------------------------------------
___________________________get value and remove value from linked list in middle_________________ lines 104 - 161

---------------------------------------------------------------------------------------------------------------------------

________________________get value form middle of list________________________________ lines 163 - 187

---------------------------------------------------------------------------------------------------------------------------
(From previous assignment repurposed the same code)
press 1 to add a value to the end linked list
press 2 to get the value of the head node and then remove it
press 3 to get the value of the head node without removing it



(Not asked for but i thought it would make it easier to know whats in the list so that you can add/remove it.)
press 4 to print out a list of all nodes 

(Required functions)
press 5 to add a value at any location.
press 6 to get value and delete a value at any location.
press 7 to get value at any location.

(Exit)
press 8 to exit





