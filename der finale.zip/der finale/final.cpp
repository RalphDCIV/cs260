#include <iostream>
#include <vector>
#include <climits>

class graph {
    int ver; //number of vertecies
    std::vector<std::vector<int>> adj;

public:

graph() : ver(0) {}

    void addv() {
        ver++; 
        adj.push_back(std::vector<int>(ver, 0)); 
        for (int i = 0; i < ver; i++) {
            adj[i].push_back(0); 
        }
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << " created a vertex with id "<< ver << std::endl;
        std::cout << "-------------------------------------------------------------" << std::endl; 
    }

    void print() { //adds new edge to the graph
        
      
        for (int i = 0; i < ver; i++) {
            for (int j = 0; j < ver; j++) {
                if (j == 0) { 
                    std::cout << adj[i][j] ; 
                }
                else
                {
                    std::cout << " - " << adj[i][j] ; 
                } 
            }
            std::cout  << std::endl; 
        }

    }



    void gedge(int adj1, int adj2, int dist) { //adds new edge to the graph
        if (adj1 > ver || adj2 > ver) {
            std::cout << "-------------------------------------------------------------" << std::endl; 
            std::cout << "one or more of the vertexes do not exist returning to menu" << std::endl;
            std::cout << "-------------------------------------------------------------" << std::endl; 
            return;
        }
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "creteing edge from " << adj1 << " " << adj2 << "with a weight of " << dist << std::endl;
        std::cout << "-------------------------------------------------------------" << std::endl; 
        adj1 -=1; //gets the inputed values (the vertexs start at 1) to correctly interact with teh graph.
        adj2 -=1;
        adj[adj1][adj2] = dist; 
        adj[adj2][adj1] = dist;

    }

    int minv (std::vector<int>& edgeary, std::vector<bool>& verary) {
        int min = INT_MAX, mindex; 
        for (int i = 0; i < ver; i++) { //until i is greater than number of vertex
            if(verary[i] == false && edgeary[i] < min) { //checks if the vertex is in the mst and if the edge is the shortest route
                min = edgeary[i]; //sets the edge to be in the key
                mindex = i;
            }
        }
        return mindex; //returns the vertex


    }


    void mst () {
        std::vector<int> mstary(ver, -1); // Array to store mst
        std::vector<int> edgeary(ver, INT_MAX); //used to store the edge distances
        std::vector<bool> verary(ver, false); //holds vertex not in mst yet

        edgeary[0] = 0; //set the start to be zero 

        for (int i = 0; i < ver - 1; i++) { // until i is one less than the number of nodes
            int u = minv(edgeary, verary); //calls the minv function to get the next lowest edge
            verary[u] = true; //sets the vertex to being added to the mst

            for ( int j = 0; j < ver; j++) { // until j is greater than the  number of vertecies
                if (adj[u][j] && verary[j] == false && adj[u][j] < edgeary[j]) { 
                    //checks if theres an edege from u to j
                    //checks that j isnt already in the tree
                    //checks if the path from u to j is the shortest path.

                    mstary[j] = u; //updates graph
                    edgeary[j] = adj[u][j];
                }
            }
        }

        std::cout << "Edge \tWeight\n"; //prints out the deets
        for (int k = 1; k < ver; k++) {
            std::cout << mstary[k]+1 << " - " << k+1 << "\t" << adj[k][mstary[k]] << "\n";
        }


    }

    void sp (int start) {
         if (start > ver) {
            std::cout << "-------------------------------------------------------------" << std::endl; 
            std::cout << "one or more of the vertexes do not exist returning to menu" << std::endl;
            std::cout << "-------------------------------------------------------------" << std::endl; 
            return;
        }
        start -=1;
        std::vector<int> dist(ver, INT_MAX); 
        std::vector<bool> path(ver, false); 

        dist[start] = 0; //sets start vertex to zero (cause your there)
        for (int count = 0; count < ver-1; count++) {
            int u = minv(dist, path);

            
            path[u] = true; //check path as having been checked

            for (int v = 0; v < ver; v++) { //checks whereter new path better then any old paths
                if (!path[v] && adj[u][v] && dist[u] != INT_MAX && dist[u] + adj[u][v] < dist[v]) {
                    dist[v] = dist[u] + adj[u][v];
                }
            }
        }

        // Print the constructed distance array
        std::cout << "Vertex \tDistance from Source\n";
        for (int i = 0; i < ver; i++) {
            std::cout << i+1 << " \t\t " << dist[i] << "\n";
        }
    }

    







};


std::pair<int, bool> input(){ // input command same as other paths
    std::string grosschoice;
    int netchoice;
    bool good = true;
    std::getline(std::cin, grosschoice);     
        try {
            netchoice = std::stoi(grosschoice);        
        } catch (const std::invalid_argument& e) { 
            netchoice = -1;
            good=false;
        } catch (const std::out_of_range& e) { 
            netchoice = -1;
            good=false;
        }
        return {netchoice, good};
}

int main() {
    graph g;
    int output;
    bool success;
    int choice;
    int a1;
    int a2;
    int a3;
    int b1;
     
      
    while(true) {
        std::cout << "" << std::endl; //menu stuff
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "---------------------Welcome to hash table-------------------" << std::endl;
        std::cout << "-------------------press 1 to add a vertex-------------------" << std::endl; 
        std::cout << "-------------press 2 to add an edge to the vertex------------" << std::endl;
        std::cout << "------------press 3 to create minnium spanning tree----------" << std::endl;
        std::cout << "----------press 4 to find the shortest path from an----------" << std::endl;
        std::cout << "------------inputed vertex to every other vertex-------------" << std::endl;
        std::cout << "-----------------------input 5 to exit-----------------------" << std::endl; 
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "What would you like to do?: ";
        std::pair<int, bool> result = input();
        choice = result.first;
        success = result.second;
        if (!(success && (choice == 1 || choice == 2 || choice == 3 || choice == 4 || choice == 5 || choice == 6 || choice == 0))) {
            std::cout << "" << std::endl;
            std::cout << "-------------------------------------------------------------" << std::endl; 
            std::cout << "Your input was not valid returning to menu" << std::endl;
            std::cout << "-------------------------------------------------------------" << std::endl; 
            std::cout << "" << std::endl;
        } else {
            if (choice==1) {
                g.addv();
                
            }  else if (choice == 2) {
                std::cout << "what is the first vertex you want to connect? (must be an integer): ";
                result = input();
                a1 = result.first;
                success = result.second;



                if (success == false) {
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "Your input was not valid returning to menu" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl;
                    continue;
                } 

                std::cout << "what is the second vertex you want to connect? (must be an integer): ";
                 result = input();
                a2 = result.first;
                success = result.second;



                if (success == false) {
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "Your input was not valid returning to menu" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl;
                    continue;
                } 

                std::cout << "what is the distance/weight of the edge? (must be an integer): ";
                result = input();
                a3 = result.first;
                success = result.second;



                if (success == false) {
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "Your input was not valid returning to menu" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl;
                    continue;
                } 

                g.gedge(a1, a2, a3);
               
            } else if (choice == 3) {

                g.mst();

                
            } else if (choice == 4) {
                std::cout << "what is the starting vertex? (must be an integer): ";
                std::pair<int, bool> result = input();
                b1 = result.first;
                success = result.second;



                if (success == false) {
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "Your input was not valid returning to menu" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl;
                    continue;
                } 

                g.sp(b1);

                
            } else if (choice == 5) {
                std::cout << "" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "----------------------------Exiting--------------------------" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                return 0;
                
            } else if (choice == 6) { // secert command to check adj matrix
                g.print();

            } else {  
                for (int i = 0; i < 9; i++) { //secret command which builds the graph for testing purposes
                    g.addv();
                }
                g.gedge(1, 2, 6);
                g.gedge(1, 7, 3);
                g.gedge(1, 5, 3);
                g.gedge(2, 5, 9);
                g.gedge(2, 3, 2);
                g.gedge(2, 7, 7);
                g.gedge(2, 6, 8);
                g.gedge(3, 5, 1);
                g.gedge(3, 4, 4);
                g.gedge(3, 6, 5);
                g.gedge(5, 9, 6);
                g.gedge(6, 8, 2);
                g.print();







                
  
            }
        }
    }







}