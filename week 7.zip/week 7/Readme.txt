read me

collisions will hapen about 1 in 10 on my small hashtable but this can be solved by having a ridiculaously klarge hastable and using some proper hashes like sha		

collisions will slow down the process from a O(1) to an O(n) in the worst possibble senario. 			
	
	
for tests simply press 1 to input.
and 2 to look up the value.
the ovberriding hashtable also has a hidden 4 command for testing theat prints out the array for added vissibility.



input two
	the input a string of your choice
	followed by an intiger.
you can then input a 2 
	input the same string and it should return the number
	for the second non overiding input another value with a string that is the same charcters in a diffrent order (rad) (dar)
	then look up both values and they should both pop up.

	