#include <iostream>
#include <vector>
#include <list>
#include <string>

struct node {
    std::string key;
    int data;
    bool full;
    node* next;
};

const int size = 10;
std::vector<std::list<node*>> hashray(size); // Using vector of lists for chaining


int hashing(std::string key) { // hash takes askii values adds them up then devides by size (10) and takes remineder
    int sum = 0;
    for (char c : key) {
        sum += static_cast<int>(c);
    }    
    return sum % size;
}

void hashsert(std::string key, int data) { //checks if spot is emty and if so adds the new node behind it
    int hashdex = hashing(key);
    node* newNode = new node{key, data, true, nullptr};

    if (hashray[hashdex].empty()) {
        hashray[hashdex].push_back(newNode);
    } else {
        for (node* n : hashray[hashdex]) {
            if (n->key == key) {

                n->data = data;
                return;
            }
        }

        hashray[hashdex].push_back(newNode);
    }

}

void hashchk(std::string key) { //checks the node and makes sure the key is the same and if not checks if there are more beihnd and repeat.
    int hashdex = hashing(key);
    for (node* n : hashray[hashdex]) {
        if (n->key == key) {
            std::cout << n->data << std::endl;
            return;
        }
    }
    std::cout << "-------------------------------------------------------------" << std::endl; 
    std::cout << "-----------------There's nothing here, send help-------------" << std::endl; 
    std::cout << "-------------------------------------------------------------" << std::endl;
}

    



//same input command i used in the past for conveinience
std::pair<int, bool> hashput(){
    std::string grosschoice;
    int netchoice;
    bool good = true;
    std::getline(std::cin, grosschoice);     
        try {
            netchoice = std::stoi(grosschoice);        
        } catch (const std::invalid_argument& e) { 
            netchoice = -1;
            good=false;
        } catch (const std::out_of_range& e) { 
            netchoice = -1;
            good=false;
        }
        return {netchoice, good};
}

int main () {
    int output;
    bool success;
    int choice;
    std::string choicekey;
    int choicedata;
    for (int i = 0; i < size; ++i) {
        hashray[i] = std::list<node*>();
    }


    while(true) {
        std::cout << "" << std::endl;
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "---------------------Welcome to hash table-------------------" << std::endl;
        std::cout << "-------------press 1 to add a value to the table-------------" << std::endl; 
        std::cout << "---------------press 2 to check value of an id---------------" << std::endl;
        std::cout << "-----------------------input 3 to exit-----------------------" << std::endl; 
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "What would you like to do?: ";
        std::pair<int, bool> result = hashput();
        choice = result.first;
        success = result.second;
        if (!(success && (choice == 1 || choice == 2 || choice == 3 || choice == 4))) {
            std::cout << "" << std::endl;
            std::cout << "-------------------------------------------------------------" << std::endl; 
            std::cout << "----------Your input was not valid returning to menu---------" << std::endl;
            std::cout << "-------------------------------------------------------------" << std::endl; 
            std::cout << "" << std::endl;
        } else {
            if (choice==1) {
                std::cout << "what is the key of the value (can be a string): ";
                std::getline(std::cin, choicekey);
                std::cout << "what is the data of the value (must be an integer): ";
                std::pair<int, bool> result = hashput();
                choicedata = result.first;
                success = result.second;



                if (success == false) {
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "----------Your input was not valid returning to menu---------" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl;
                    continue;
                } 
                hashsert(choicekey, choicedata);
                
            }  else if (choice == 2) {
                std::cout << "what is the key of the value (can be a string): ";
                std::getline(std::cin, choicekey);
                hashchk(choicekey);

                
            }  else if (choice == 3) {
                std::cout << "" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "----------------------------Exiting--------------------------" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                return 0;
            } else {
                return -1;
            }
        }
    }






}