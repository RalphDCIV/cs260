#include <iostream>
#include <vector>
#include <list>
#include <string>

struct node {
    std::string key;
    int data;
    bool full;
};

const int size = 10;
node hashray[size];

int hashing(std::string key) { // hash takes askii values adds them up then devides by size (10) and takes remineder


    int sum = 0;

    for (char c : key) {
        sum += static_cast<int>(c);
    }



    
    return sum % size;
}

void hashsert(std::string key, int data) { //simple program just overites value
    int hashdex = hashing(key);
    hashray[hashdex].key = key;
    hashray[hashdex].data = data;
    hashray[hashdex].full = true;
}

void hashchk(std::string key) { //hashes value then cheks the spot for the value
    int hashdex = hashing(key);
    if (hashray[hashdex].full == true) {
        std::cout << hashray[hashdex].data << std::endl;
        return;
    } else {
        std::cout << "" << std::endl;
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "----------------theres nothing here, send help---------------" << std::endl; 
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "" << std::endl;
        return;
    }

    
}


//same input command i used in the past for conveinience
std::pair<int, bool> hashput(){
    std::string grosschoice;
    int netchoice;
    bool good = true;
    std::getline(std::cin, grosschoice);     
        try {
            netchoice = std::stoi(grosschoice);        
        } catch (const std::invalid_argument& e) { 
            netchoice = -1;
            good=false;
        } catch (const std::out_of_range& e) { 
            netchoice = -1;
            good=false;
        }
        return {netchoice, good};
}

int main () {
    int output;
    bool success;
    int choice;
    std::string choicekey;
    int choicedata;
    for (int i = 0; i < size; ++i) { //initzilize
        hashray[i].key = ""; 
        hashray[i].data = -1;
        hashray[i].full =  false;
    }


    while(true) {
        std::cout << "" << std::endl; //menu stuff
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "---------------------Welcome to hash table-------------------" << std::endl;
        std::cout << "-------------press 1 to add a value to the table-------------" << std::endl; 
        std::cout << "---------------press 2 to check value of an id---------------" << std::endl;
        std::cout << "-----------------------input 3 to exit-----------------------" << std::endl; 
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "What would you like to do?: ";
        std::pair<int, bool> result = hashput();
        choice = result.first;
        success = result.second;
        if (!(success && (choice == 1 || choice == 2 || choice == 3 || choice == 4))) {
            std::cout << "" << std::endl;
            std::cout << "-------------------------------------------------------------" << std::endl; 
            std::cout << "----------Your input was not valid returning to menu---------" << std::endl;
            std::cout << "-------------------------------------------------------------" << std::endl; 
            std::cout << "" << std::endl;
        } else {
            if (choice==1) {
                std::cout << "what is the key of the value (can be a string): ";
                std::getline(std::cin, choicekey);
                std::cout << "what is the data of the value (must be an integer): ";
                std::pair<int, bool> result = hashput();
                choicedata = result.first;
                success = result.second;



                if (success == false) {
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "----------Your input was not valid returning to menu---------" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl;
                    continue;
                } 
                hashsert(choicekey, choicedata);
                
            }  else if (choice == 2) {
                std::cout << "what is the key of the value (can be a string): ";
                std::getline(std::cin, choicekey);
                hashchk(choicekey);

                
            }  else if (choice == 3) {
                std::cout << "" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "----------------------------Exiting--------------------------" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                return 0;
            } else {  //secret command to print out list for testing.
                for (int i = 0; i < size; ++i) {
                    std::cout << "i " << i << std::endl;;
                    std::cout << "data " << hashray[i].data << std::endl;;
                    std::cout << "key " << hashray[i].key << std::endl;;
                    std::cout << "full " << hashray[i].full << std::endl;;
                }
            }
        }
    }






}