#include <iostream>
#include <string>


struct node {
    int data; //data for the node
    node* next; //the data for the next node in the chain

};


node* createnode(int value) {
    node* newnode = new node; //declares a new node
    newnode->data = value; // sets the value of the node to the given value
    newnode->next = nullptr; //sets the node to have a next value of null 
    return newnode; //returns the node


}


void enque(node*& head, int value) {
    node* newnode = createnode(value); //creates the new node so it can then be added to the linked list

    if (head == nullptr) {  // if there is no head...

        head = newnode; //..make this node the head.

    } else {
        node* current = head; // variable current is set to start at the head.

        while (current->next != nullptr) { //while the next node is not nothing...
            current = current->next;        //...move to the next node
        }
            current->next = newnode; //set the pointer of the current node (the last one in the list) to be the newly created Node. (effectivly adding it to the end of the list)
    }
}





int deque(node*& head) {

 if (head == nullptr){ //if there is nothing in the list...
    std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
    std::cout << "-------------------------------------------------------------" << std::endl; 
    std::cout << "No Data stored " << std::endl; //...tell the user and...
    return -1;  //...return -1.
 } else {
    int newdata = head->data; //grab the data from the headnode...
    node* current = head; // set the head to be a sepret vairaiable
    head = current->next; //set the next node to be the head
    delete current; //delete the head
    std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
    std::cout << "-------------------------------------------------------------" << std::endl; 
    return newdata; //... and return it.
 }
}

int peek(node*& head) {

 if (head == nullptr){ //if there is nothing in the list...
    std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
    std::cout << "-------------------------------------------------------------" << std::endl; 
    std::cout << "No Data stored " << std::endl; //...tell the user and...
    return -1;  //...return -1.
 } else {
    int newdata = head->data; //grab the data from the headnode...
    std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
    std::cout << "-------------------------------------------------------------" << std::endl; 
    return newdata; //... and return it.
 }
}


int main() {
    node* head = nullptr; //set the head to be nothing for we have nothing.
    std::string grosschoice;
    grosschoice = "null";
    int netchoice = 0;
    std::string grossnode;
    grossnode = "null";
    int devalue=0;
    int pevalue=0;
    int netnode = 0;
    bool on = true;
    while (on == true) {
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "press 1 to add a value to the end linked list" << std::endl;                  //Menu
        std::cout << "press 2 to get the value of the head node and then remove it" << std::endl;   //Menu
        std::cout << "press 3 to get the value of the head node without removing it" << std::endl;  //Menu
        std::cout << "press 4 to exit" << std::endl;                                                //Menu
                std::cout << "what would you like to do: ";                                      //Menu
        std::getline(std::cin, grosschoice);     //Get user input as str
        try {
            netchoice = std::stoi(grosschoice);        //change to int
        } catch (const std::invalid_argument& e) { //make sure it works
            netchoice = -1;
        } catch (const std::out_of_range& e) { // make sure it works again
            netchoice = -1;
        }



        if (netchoice == 1){ // choice for 1
            std::cout << "Input a valid intiger Value for the Node: ";    
            std::getline(std::cin, grosschoice);    //Get user input for value in Node
        try {
            netnode = std::stoi(grosschoice);
        } catch (const std::invalid_argument& e) {
            netnode = -1;
        } catch (const std::out_of_range& e) {
            netnode = -1;
        }
        enque(head, netnode); //call enque and let it do its thing

        } else if (netchoice == 2) { //choice for 2
            devalue = deque(head); //run deque

            std::cout << "Value: "<< devalue <<std::endl; //print the value
        } else if (netchoice == 3) { //choice for 3
            pevalue = peek(head); //run peek
            std::cout << "Value: "<< pevalue <<std::endl; //print the value
        } else if (netchoice == 4) { //cholice for 4
            return 0; //exit program
        } else { //incorrect value
            std::cout << "Sorry didnt get that, please input a valid action... Or else." << std::endl; //yell at them and make an else pun.
        }

    }






}