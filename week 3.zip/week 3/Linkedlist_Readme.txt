Test
Type
1 to make a new variable
input an intiger value of your choice like  7
1 again
type a non intiger like "Fail"
1 a final time and type a float like 1.86

now type 3 and you should get 7
now tpe 2 and you should get 7 again
now type 2 agian and you should get -1 (null for invalid intiger)
now type 2 agin and it should be 1 (just cuts of the decimal points)
type 2 again and it should say No data stored and give a value of -1