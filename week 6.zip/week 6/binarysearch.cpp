#include <iostream>
#include <string>

using namespace std;





struct node {
    int data; //store the value
    int dup; //number of duplicates
    node* left; //left pointer
    node* right; //right pointer

};

void buffer();
std::pair<int, bool> binput();
void borphan(node*& current, node*& prev, node* node::*side, node*& head);
void bsort(node*& head, int value);
void bkill(node*& head, int value);
void btravel(node*& head);
void binotravel (node*& head);

void buffer(){
    std::cout << "" << std::endl;
    return;
}


node* createnode(int value) { //same node comand as previous code adjusted for use here
    node* newnode = new node; //the birth of a new node...
    newnode->data = value; //sets node's value
    newnode->dup = 0; //sets the duplicates to 1 meaning there is only one (this one)
    newnode->left = nullptr; //sets nullptsrs for left and right
    newnode->right = nullptr; 
    return newnode; //return the new node
}

void bsort(node*& head, int value) { //call create node then sort the new node in the binary tree
    node* newnode = createnode(value);

    if (head == nullptr) { //checks if there are any nodes at all
        head = newnode; // if there isnat make this node the head of a new tree
        std::cout << "" << std::endl;
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "-------------------------New Node added----------------------" << std::endl; 
        std::cout << "-------------------------------------------------------------" << std::endl; 
        buffer();
        return; //return to main
    } else { //otherwise...
        node* current = head; //set the current node to be the head
        while (true) { //while true or just run until it hits a return
            if (current->data > newnode->data) { //if its bigger go right
                if (current->right == nullptr) { 
                    current->right=newnode;
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "-------------------------New Node added----------------------" << std::endl; 
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    buffer();
                    return;
                } else {
                    current=current->right;
                }
            } else if (current->data < newnode->data) { //if smaller go left
                if (current->left == nullptr) {
                    current->left=newnode;
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "-------------------------New Node added----------------------" << std::endl; 
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    buffer();
                    return;
                } else {
                    current=current->left;
                }

            } else if (current->data == newnode->data) {// if its a duplicate delete the node and increase the duplicate count by 1
                current->dup +=1;
                delete newnode;
                std::cout << "" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "----------------------Duplicate node added-------------------" << std::endl; 
                std::cout << "-------------------------------------------------------------" << std::endl; 
                buffer();
                return;
            } else { //if none of the other's trigger idk what happened so i yell at you.
                delete newnode;
                std::cout << "" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "-------Something went wrong, I feel no remorse for you-------" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                buffer();
                return;
            }




        }


    }
}






void bkill(node*& head, int value) {
    if (head == nullptr){ //if there is nothing in the list...
        std::cout << "" << std::endl;
        std::cout << "-------------------------------------------------------------" << std::endl; //to make menu look more clean
        std::cout << "------------------------No Data stored-----------------------" << std::endl; //...tell the user and...
        std::cout << "-------------------------------------------------------------" << std::endl; 
        buffer();
        return;
    } else {
        node* current = head; //set the current node to be the head
        node* prev;
        node* node::*side = nullptr;//to track whitch side prev connects to current from
        while (true) { //while true or just run until it hits a return
            if (current->data > value) { //if its bigger go right
                if (current->right == nullptr) { 
                        std::cout << "" << std::endl;
                        std::cout << "-------------------------------------------------------------" << std::endl; 
                        std::cout << "------------What you are looking for does not exist----------" << std::endl; 
                        std::cout << "-------------------------------------------------------------" << std::endl; 
                        buffer();
                    return;
                } else {
                    prev = current;
                    current=current->right;
                    side=&node::right;
                }
            } else if (current->data < value) { //if smaller go left
                if (current->left == nullptr) {
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "------------What you are looking for does not exist----------" << std::endl; 
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    buffer();
                    return;
                } else {
                    prev = current;
                    current=current->left;
                    side = &node::left;
                }

            } else if (current->data == value) {//if the node is the same as the value than bobs your uncle
                if (current->dup > 0) {
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "--------The node your are deleting has multiple copies-------" << std::endl;
                    std::cout << "-------would you like to delete all copies or just one-------" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "" << std::endl;
                    std::cout << "press 1 to delete all or 2 to delete only one copy: " << std::endl;
                    std::pair<int, bool> result = binput();
                    int choice = result.first;
                    bool success = result.second;
                    if (!(success && (choice == 1 || choice == 2))) {
                        std::cout << "" << std::endl;
                        std::cout << "-------------------------------------------------------------" << std::endl; 
                        std::cout << "----------Your input was not valid returning to menu---------" << std::endl;
                        std::cout << "-------------------------------------------------------------" << std::endl; 
                        buffer();
                        return;
                    } else {
                        if (choice ==1) {
                        borphan(current, prev, side, head); //its borphin time
                        std::cout << "" << std::endl;
                        std::cout << "-------------------------------------------------------------" << std::endl; 
                        std::cout << "-------------------------Node Deleted------------------------" << std::endl;
                        std::cout << "-------------------------------------------------------------" << std::endl; 
                        buffer();
                        return;
                        } else {
                            current->dup-=1;
                            std::cout << "" << std::endl;
                            std::cout << "-------------------------------------------------------------" << std::endl; 
                            std::cout << "-----------------------Duplicate Deleted---------------------" << std::endl;
                            std::cout << "-------------------------------------------------------------" << std::endl; 
                            buffer();
                            return;
                        }
                    }


                } else {
                    borphan(current, prev, side, head); //its borphin time
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "-------------------------Node Deleted------------------------" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    buffer();
                    return;
                }




            } else { //if none of the other's trigger idk what happened so i yell at you.
                std::cout << "" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "-------Something went wrong, I feel no remorse for you-------" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                buffer();
                return;
            }




        }



    }


}

void borphan(node*& current, node*& prev, node* node::*side, node*& head) {
    std::cout << "its borphin time" << std::endl;
    bool root = false;
    if (current == head) { //to solve issues with deleteing the head/root node
        root = true;
    }
    if (current->right==nullptr && current->left==nullptr ) {//if both
        delete current;
        prev->*side=nullptr; //just delete and set its spot to null


    } else if (current->right==nullptr || current->left==nullptr) {//if one
        if (!(current->right==nullptr)) {
            if (root) {
                head=current->right;
            } else {
                prev->*side=current->right; //move parentless node to the current nodes spot
            }
            delete current;
        } else {
            if (root) {
                head=current->left;
            } else {
                prev->*side=current->left; //move parentless node to the current nodes spot
            }
            delete current;
        }


    } else if (!(current->right==nullptr || current->left==nullptr) ) {//if neither

               node* cousin;
               node* aunt;
                cousin = current->right;
                while(cousin->left != nullptr){
                    aunt = cousin;
                    cousin=cousin->left;
                }
                if (cousin->right == nullptr) {
                    aunt->left = nullptr; 
                } else {
                    aunt->left = cousin->right;
                }
                if (root) {
                    head = cousin;
                } else {
                    prev->*side = cousin;
                }
                
                cousin->left = current->left;
                cousin->right = current->right;
                delete current;



    } else {
        std::cout << "" << std::endl;
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "-------Something went wrong, I feel no remorse for you-------" << std::endl;
        std::cout << "-------------------------------------------------------------" << std::endl; 
        buffer();
        return;
    }



}

std::pair<int, bool> binput(){
    std::string grosschoice;
    int netchoice;
    bool good = true;
    std::getline(std::cin, grosschoice);     //Get user input as str
        try {
            netchoice = std::stoi(grosschoice);        //change to int
        } catch (const std::invalid_argument& e) { //make sure it works
            netchoice = -1;
            good=false;
        } catch (const std::out_of_range& e) { // make sure it works again
            netchoice = -1;
            good=false;
        }
        return {netchoice, good};
}



void binotravel (node*& head) {

     if (head != nullptr) {
        binotravel(head->left);
        cout << head->data << " with " << head->dup  << " duplicates" <<std::endl;
        binotravel(head->right);
    }



}


int main () {
    node* head = nullptr;
    bool success;
    int choice;

    while(true) {
        std::cout << "" << std::endl;
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "--------------------Welcome to binary tree-------------------" << std::endl;
        std::cout << "-------------input 1 to input a value in the tree------------" << std::endl; 
        std::cout << "-----------input 2 to remove a value from the tree-----------" << std::endl;
        std::cout << "-----------------input 3 to traverse the tree----------------" << std::endl; 
        std::cout << "-----------------------input 4 to exit-----------------------" << std::endl; 
        std::cout << "-------------------------------------------------------------" << std::endl; 
        std::cout << "What would you like to do?: ";
        std::pair<int, bool> result = binput();
        choice = result.first;
        success = result.second;
        if (!(success && (choice == 1 || choice == 2 || choice == 3|| choice == 4))) {
            std::cout << "" << std::endl;
            std::cout << "-------------------------------------------------------------" << std::endl; 
            std::cout << "----------Your input was not valid returning to menu---------" << std::endl;
            std::cout << "-------------------------------------------------------------" << std::endl; 
            buffer();
        } else {

        
            if (choice==1) {
                std::cout << "" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "-------------------adding value to the tree------------------" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "what intiger value do you want to add?: ";
                std::pair<int, bool> result = binput();
                choice = result.first;
                success = result.second;
                if (success == false) {
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "----------Your input was not valid returning to menu---------" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    buffer();
                } else {
                    bsort(head, choice);
                }


             } else if (choice == 2) {
                std::cout << "" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "-----------------removing value from the tree----------------" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "what intiger value do you want to remove?: ";
                std::pair<int, bool> result = binput();
                choice = result.first;
                success = result.second;
                if (success == false) {
                    std::cout << "" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    std::cout << "----------Your input was not valid returning to menu---------" << std::endl;
                    std::cout << "-------------------------------------------------------------" << std::endl; 
                    buffer();
                    
                } else {
                    bkill(head, choice);
                }


            } else if (choice == 3) {
                std::cout << "" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "----------------------Traversing the tree--------------------" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                binotravel(head);

            } else if (choice == 4) {
                std::cout << "" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                std::cout << "----------------------------Exiting--------------------------" << std::endl;
                std::cout << "-------------------------------------------------------------" << std::endl; 
                return 0;
            } else {
                return -1;
            }

        } 
    }
return 1;
}
