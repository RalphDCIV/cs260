theory crafting stuff      
  //actaul sorting algorithm
        /*
        check wether current value is bigger or larger
        then check wether the node corospondiong id nullpter
        if yes set then point the current nodes corosponsing pointer to this node
        otherwise go to the nset node and repeat
        somthing like this probably
        */
       
       /*
       While on
       if current node > newnode
        then check if node* right is nullptr
        if it isnt then set right to be the current node an then repeat
        if it is then set the right pointer to point to this node.
       elif current node < new node
        check if node* left id nullptr
        if no then set left node to be current node and repeat the process
        else set the left pointer to point to the new node
       */

	//node remove
	/*
	take value
	check if value is bigger, smaller or equal to the current node
	if its the same delete the node
	otherwise check the pointer to the next value
	if that value is null then  return that no node could be deleted because it does not exist
	repeat until either aither it retuens no value or a value is deleted

	when a value is deleted check for children 
	if none then good
	if theres one shift the child to the place of the deletde node
	if there are two then jump up thr ight(larger) path and then search for the smallest value on that side and move...
	...it to replace the dleted mode

	*/
	/*

	*/
----------------------------------------------- test -------------------------------------------------------------------

	test for if its working 
	add a 9 5 4 3 2 1 15 20 12 11 14 19 32 as the numbers of the tree in that order
	traverse the tree should get all the numbers in order
	delete 2
	then delete 3
	and then delete 15
	after this the tree should not crash and when printing the numbers in order they will work
	delete 9 to make sure it works when the deleted node is the head
	then add 1 multiple times (at least until there at least 2 duplicate 1s(you can check this with the 3 command))
	delete the one and choose to only delete 1 copy 
	it should only delete 1 copy of the 1
	then dlete 1 again and choose to delete all copies and it should delete every 1 when the tree is checked.
	if all this works it is working as intended (or at least i havent found anything else to test that might break it.


---------------------------------------------------- big(0)-------------------------------------------------------------------
	a binary serach tree that is ordered has a big(O) of O(Log n)
	While an unordered tree has has a big(O) of O(n)
	this is because a bst is sorted allows for the program to quickly reach the desired niode without haveing to go through a swath of other nodes
	while and normal bt may have to go through everysingle node to find the correct node as it could be anywhere which can really slow down the runtime if the tree becomes very large.						
	
	